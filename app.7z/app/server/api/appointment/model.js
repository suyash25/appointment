
// Dependencies
var restful = require('node-restful');
var mongoose = restful.mongoose;

// Schema
var appointmentSchema = new mongoose.Schema({
  Availabilty: Date,
  Doctors: String,
  Speciality: String,
  cost: String
});

// Return model
module.exports = restful.model('Appointments', appointmentSchema);