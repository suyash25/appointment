
'use strict';

angular.module('appointmentApp', ['ngMaterial'])